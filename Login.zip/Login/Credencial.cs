using System.ComponentModel.DataAnnotations;

//Clase creada para que se puedan usar las clases de Registro y Login a la vez
//y no salte ambig�edad en los datos(llegaban a salir datos repetidos y no compilaba)

namespace Login.Models
{
    public class Credencial
    {
        [Required]
        public string Usuario { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Contrase�a { get; set; }
    }
}