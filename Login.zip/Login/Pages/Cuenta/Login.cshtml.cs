using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Login.Models;

namespace Login.Pages.Cuenta
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public Credencial Credencial { get; set; }

        public IActionResult OnPost()
        {
            //El usuario no le deja avanzar si los datos no estan puestos 
            if (!ModelState.IsValid)
            {
                return Page();
            }

        // Redigiremos al usuario al inicio si introduce todos los datos
            return RedirectToPage("/Index");
        }

        public void OnGet()
        {
            //Dejamos preseleccionado admin como usuario por defecto
            //(por dejar algo preseleccionado) No es necesario de todas formas
            this.Credencial = new Credencial { Usuario = "admin" };
        }
    }
}