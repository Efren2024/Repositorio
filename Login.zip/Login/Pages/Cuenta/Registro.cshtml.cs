using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Login.Models;

namespace Login.Pages.Cuenta
{
    public class RegistroModel : PageModel
    {
        [BindProperty]
        public Credencial Credencial { get; set; }

        public IActionResult OnPost()
        {
            //El usuario no le deja avanzar si los datos no estan puestos
            if (!ModelState.IsValid)
            {
                // Si el modelo no es v�lido, volveremos a mostrar el formulario de registro
                return Page();
            }
            
            // Redirigiremos al usuario al formulario de inicio de sesi�n
            return RedirectToPage("/Cuenta/Login");
        }
    }
}