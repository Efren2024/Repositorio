﻿using System.ComponentModel.DataAnnotations;

namespace PantallaClientes.Models
{
    // Enumeración para representar el estado de una parte
    public enum EstadoParte
    {
        Abierto,
        Finalizado
    }

    // Clase que representa una parte
    public class Parte
    {
        public EstadoParte Estado { get; set; }
        public string Empresa { get; set; }
        public int Id { get; set; }

        public string Descripcion { get; set; }

        public byte[] Foto { get; set; } // Propiedad para la foto como un array de bytes
        public string FirmaElectronica { get; set; } // Propiedad para la firma electrónica como una cadena de texto

    }

    // Clase que representa un cliente
    public class Cliente
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        private string numero;

        // Propiedad para el número de teléfono del cliente
        [RegularExpression(@"^(\d{3}[-\s]?){2}\d{3}$", ErrorMessage = "El formato del número de teléfono no es válido. Por favor, pruebe: xxx-xxx-xxx.")]
        [Required(ErrorMessage = "El número de teléfono es obligatorio.")]
        public string Numero
        {
            get
            {
                return numero;
            }
            set
            {
                numero = value;
            }
        }

        private string email;

        // Propiedad para la descripción del producto
        [RegularExpression(@"^$|^no\sdisponible$|^[\w-\.]+@([\w-]+\.)+[\w-]{2,3}$", ErrorMessage = "El formato del correo es : ejemplo@gmail.com.")]
        public string Email
        {
            get
            {
                // Verifica si el email es nulo o vacío, o si es igual a "no disponible" (sin importar mayúsculas y minúsculas)
                return string.IsNullOrEmpty(email) || email.Equals("no disponible", StringComparison.OrdinalIgnoreCase) ? "no disponible" : email;
            }
            set
            {
                // Asigna el valor del email, manteniendo su caso original
                email = value;
            }
        }
        public string Localizacion { get; set; }

        // Lista de partes asociadas al cliente
        public List<Parte> Partes { get; set; } = new List<Parte>();

        // Lista de centros asociados al cliente
        public List<string> Centros { get; set; } = new List<string>();

        // Lista de contactos asociados al cliente
        public List<string> Contactos { get; set; } = new List<string>();

    }
}