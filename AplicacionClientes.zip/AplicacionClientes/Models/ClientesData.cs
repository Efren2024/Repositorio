﻿namespace PantallaClientes.Models
{
    public static class ClientesData
    {
        // Lista interna para almacenar clientes
        public static List<Cliente> ClientesList { get; set; } = new List<Cliente>
        {
            new Cliente { Id = 1, Nombre = "Ahora S.L", Numero = "665897512", Email = "no disponible", Localizacion = "C. de Pintor Ribera, 15, 38007 Santa Cruz de Tenerife", Centros = new List<string> {"Centro 1" , "Centro 2" }, Contactos = new List<string> { "Contacto 1", "Contacto 2" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"}
                } },

            new Cliente { Id = 2, Nombre = "Bussiness International", Numero = "665897346", Email = "bussinessinternational@gmail.com", Localizacion = "C. de Velázquez, 94, 1ª, Salamanca, 28006 Madrid", Centros = new List<string> {"Centro 1" }, Contactos = new List<string> { "Contacto 1", "Contacto 2" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 3, Nombre = "Fast and Furious", Numero = "626097156", Email = "fastandfurious@gmail.com", Localizacion = "Rúa Elduayen, 8, 36202 Vigo, Pontevedra", Centros = new List<string> {"Centro 1" , "Centro 2" }, Contactos = new List<string> {},Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 4, Nombre = "Flexygo", Numero = "686097456", Email = "flexygo@gmail.com", Localizacion = "Carrer dels Ceramistes, 19, 46120 Alboraia, Valencia",Centros = new List<string> {"Centro 1" , "Centro 2" }, Contactos = new List<string> { "Contacto 1" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                } },

            new Cliente { Id = 5, Nombre = "Gronsa S.L", Numero = "686097159", Email = "gronsasl@gmail.com", Localizacion = "C. del Doctor Vicent Zaragoza, 1, Benimaclet, 46020 València, Valencia",Centros = new List<string> {"Centro 1" , "Centro 2", "Centro 3" }, Contactos = new List<string> { "Contacto 1", "Contacto 2" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 6, Nombre = "High Five solutions", Numero = "686097186", Email = "highfivesolutions@gmail.com", Localizacion = "Tuinschouw 8, 4131 MD Vianen, Países Bajos", Centros = new List<string> {"Centro 2" }, Contactos = new List<string> { "Contacto 1" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 7, Nombre = "Kurono", Numero = "686097176", Email = "kurono@gmail.com", Localizacion = "2 Chome-10-22 Kita-Aoyama, Minato City, Tokyo 107-0061, Japón", Centros = new List<string> { }, Contactos = new List<string> { "Contacto 1", "Contacto 2", "Contacto 3" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 8, Nombre = "MicroHard", Numero = "686096156", Email = "microhard@gmail.com", Localizacion = "150 Country Hills Landing NW, Calgary, AB T3K 5P3, Canadá", Centros = new List<string> {"Centro 1" , "Centro 2", "Centro 3" }, Contactos = new List<string> { "Contacto 1", "Contacto 2", "Contacto 3", "Contacto 4" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 9, Nombre = "Muralas S.L", Numero = "685097156", Email = "muralas@gmail.com", Localizacion = "Rúa Frai Plácido Rei Lemos, 1, 27004 Lugo", Centros = new List<string> { }, Contactos = new List<string> {},Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },

            new Cliente { Id = 10, Nombre = "Peix productions", Numero = "686047156", Email = "peixproductions@gmail.com", Localizacion = "1600 Pennsylvania Avenue NW, Washington, DC 20500, Estados Unidos", Centros = new List<string> {"Centro 1" , "Centro 2" }, Contactos = new List<string> { "Contacto 1", "Contacto 2" },Partes = new List<Parte>
                {

                } },

            new Cliente { Id = 11, Nombre = "prueba dani", Numero = "686093156", Email = "no disponible", Localizacion = "C.Gran Vía, 29, Centro, 28013 Madrid", Centros = new List<string> {"Centro 1" , "Centro 2" }, Contactos = new List<string> { "Contacto 2" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 2"},
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 2"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2" }
                } },

            new Cliente { Id = 12, Nombre = "prueba lead", Numero = "682097156", Email = "no disponible", Localizacion = "Calle de María de Molina, 33, Chamartín, 28006 Madrid", Centros = new List<string> {"Centro 2" }, Contactos = new List<string> {},Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                } },

            new Cliente { Id = 13, Nombre = "Qlick & Go", Numero = "686017156", Email = "qlick&go@gmail.com", Localizacion = "C. de Orense, 85, Edificio Lexington, Tetuán, 28020 Madrid", Centros = new List<string> {}, Contactos = new List<string> { "Contacto 1", "Contacto 2" },Partes = new List<Parte>
                {
                    new Parte { Estado = EstadoParte.Abierto, Empresa = "Empresa 1"},
                    new Parte { Estado = EstadoParte.Finalizado, Empresa = "Empresa 2"}
                } },
        };
    }
}