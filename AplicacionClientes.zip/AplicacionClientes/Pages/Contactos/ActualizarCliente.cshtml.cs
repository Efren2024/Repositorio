using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PantallaClientes.Models;

namespace PantallaClientes.Pages.Contactos
{
    public class ActualizarClienteModel : PageModel
    {
        [BindProperty]
        // Propiedad para almacenar los datos del cliente a actualizar
        public Cliente Cliente { get; set; }

        // Metodo para manejar solicitudes GET
        public IActionResult OnGet(int? id)
        {
            if (id == null)
            {
                // Resultado que se devuelve si no se proporciona un ID
                return NotFound();
            }

            // Busca el cliente con el ID proporcionado
            Cliente = ClientesData.ClientesList.FirstOrDefault(c => c.Id == id);

            if (Cliente == null)
            {
                // Resultado que se devuelve si el cliente no est� en la lista
                return NotFound();
            }

            // Devuelve la p�gina de actualizaci�n con los detalles del cliente cargados 
            return Page();
        }

        // Metodo para manejar solicitudes POST
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                // Devuelve la p�gina de actualizaci�n si el modelo no es v�lido
                return Page();
            }

            var existingCliente = ClientesData.ClientesList.FirstOrDefault(c => c.Id == Cliente.Id);

            if (existingCliente != null)
            {
                // Actualiza los detalles del cliente existente con los nuevos detalles
                existingCliente.Nombre = Cliente.Nombre;
                existingCliente.Numero = Cliente.Numero;
                existingCliente.Email = Cliente.Email;
                existingCliente.Localizacion = Cliente.Localizacion;
            }

            return RedirectToPage("./Detalles", new { id = Cliente.Id });
        }
    }
}