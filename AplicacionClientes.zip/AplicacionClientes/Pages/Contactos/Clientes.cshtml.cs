using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PantallaClientes.Models;

namespace PantallaClientes.Pages.Contactos
{
    public class ClientesModel : PageModel
    {
        // Propiedad para almacenar el t�rmino de b�squeda desde la URL 
        [BindProperty(SupportsGet = true)]
        public string SearchString { get; set; }

        // Lista de los clientes que se muestran en la tabla
        public IList<Cliente> Clientes { get; set; }

        // Propiedad para almacenar el nuevo cliente
        [BindProperty]
        public Cliente NuevoCliente { get; set; }

        // Propiedad para la URL de la p�gina parcial
        public string PartialPageUrl => "/Contactos/Clientes?handler=SearchPartial";

        // Metodo usado cuando se realiza la solicitud GET
        public void OnGet()
        {
            // Simulando una lista de clientes en memoria
            var clientesList = ClientesData.ClientesList.ToList();

            // Aplica la l�gica de b�squeda si se proporciona un t�rmino de b�squeda
            if (!string.IsNullOrEmpty(SearchString))
            {
                // Filtra la lista de clientes basandose en el termino de busqueda 
                Clientes = clientesList.Where(c => c.Nombre.Contains(SearchString, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            else
            {
                // Si no hay termino de busqueda, muestra todos los clientes
                Clientes = clientesList;
            }

            // Verifica si la lista de clientes est� vac�a despu�s de a`licar el flitro de b�squeda
            if (!string.IsNullOrEmpty(SearchString) && !Clientes.Any())
            {
                TempData["ErrorMessage"] = "No se encontraron clientes que coincidan con la b�squeda";
            }
            else
            {
                // Limpiar el mensaje de error si hay resultados
                TempData["ErrorMessage"] = null;
            }
        }

        // Manejador para la b�squeda Ajax
        public PartialViewResult OnGetSearch(string searchString)
        {
            // Filtra la lista de clientes seg�n el t�rmino de b�squeda
            var filteredClientes = string.IsNullOrEmpty(searchString)
                ? ClientesData.ClientesList
                : ClientesData.ClientesList.Where(c => c.Nombre.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();

            // Devuelve una vista parcial con los resultados filtrados
            return Partial("_SearchResultsPartial", filteredClientes);
        }

        // Manejador para la carga inicial de la p�gina parcial
        public PartialViewResult OnGetSearchPartial(string searchString)
        {
            // Similar a OnGetSearch, pero sin filtrar la lista inicialmente
            var clientesList = ClientesData.ClientesList.ToList();

            if (!string.IsNullOrEmpty(searchString))
            {
                Clientes = clientesList.Where(c => c.Nombre.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            else
            {
                Clientes = clientesList;
            }

            return Partial("_SearchResultsPartial", Clientes);
        }

        public IActionResult OnPost()
        {
            // Verifica si NuevoCliente es nulo antes de agregarlo a la lista
            if (NuevoCliente != null)
            {
                // Simplemente agrega el nuevo cliente a la lista en memoria
                ClientesData.ClientesList.Add(NuevoCliente);

                // Redirecciona a la p�gina de Detalles del nuevo cliente
                return RedirectToPage("./Detalles", new { id = NuevoCliente.Id });
            }

            // Obt�n el t�rmino de b�squeda actual
            string searchString = Request.Query["searchString"];

            // Redirecciona a la p�gina de Clientes con el t�rmino de b�squeda
            return RedirectToPage("./Clientes", new { searchString });
        }
    }
}