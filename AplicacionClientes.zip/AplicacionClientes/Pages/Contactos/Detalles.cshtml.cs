using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PantallaClientes.Models;

namespace PantallaClientes.Pages.Contactos
{
    public class DetallesModel : PageModel
    {
        public Cliente Cliente { get; set; }

        // Seccion de Otros
        public int CentrosCount { get; set; }
        public int ContactosCount { get; set; }

        // Seccion de Partes
        public List<Parte> ParteAbiertas { get; set; }
        public List<Parte> ParteFinalizadas { get; set; }

        // Nombres de los tipos de partes
        public string ParteMano { get; } = "Parte_mano";
        public string ParteObra { get; } = "Parte_Obra";
        public string ParteDesp { get; } = "Parte_desp";

        public void OnGet(int? id)
        {
            if (id == null)
            {
                return;
            }

            // Simulando una lista de clientes en memoria
            Cliente = ClientesData.ClientesList.FirstOrDefault(c => c.Id == id);

            if (Cliente == null)
            {
                return;
            }

            // Contar la cantidad de centros y contactos
            CentrosCount = Cliente.Centros?.Count ?? 0;
            ContactosCount = Cliente.Contactos?.Count ?? 0;

            // Obtener partes abiertas y finalizadas y asignarlas al modelo
            ParteAbiertas = Cliente.Partes.Where(p => p.Estado == EstadoParte.Abierto).ToList();
            ParteFinalizadas = Cliente.Partes.Where(p => p.Estado == EstadoParte.Finalizado).ToList();
        }

        public IActionResult OnPostAgregarParteAbierta(int clienteId, string nuevaParteAbierta)
        {
            if (string.IsNullOrWhiteSpace(nuevaParteAbierta))
            {
                ModelState.AddModelError(string.Empty, "Debe especificar el nombre de la nueva parte abierta.");
                return Page();
            }

            // Encontrar el cliente correspondiente en la lista
            var cliente = ClientesData.ClientesList.FirstOrDefault(c => c.Id == clienteId);

            if (cliente == null)
            {
                return NotFound();
            }

            // Crear una nueva parte abierta con los datos proporcionados
            var nuevaParte = new Parte { Estado = EstadoParte.Abierto, Empresa = nuevaParteAbierta };

            // Agregar la nueva parte al cliente
            cliente.Partes.Add(nuevaParte);

            return RedirectToPage("./Detalles", new { id = clienteId });
        }

        public IActionResult OnPostAgregarParteFinalizada(int clienteId, string nuevaParteFinalizada)
        {
            if (string.IsNullOrWhiteSpace(nuevaParteFinalizada))
            {
                ModelState.AddModelError(string.Empty, "Debe especificar el nombre de la nueva parte finalizada.");
                return Page();
            }

            // Encontrar el cliente correspondiente en la lista
            var cliente = ClientesData.ClientesList.FirstOrDefault(c => c.Id == clienteId);

            if (cliente == null)
            {
                return NotFound();
            }

            // Crear una nueva parte finalizada con los datos proporcionados
            var nuevaParte = new Parte { Estado = EstadoParte.Finalizado, Empresa = nuevaParteFinalizada };

            // Agregar la nueva parte al cliente
            cliente.Partes.Add(nuevaParte);

            return RedirectToPage("./Detalles", new { id = clienteId });
        }

        public IActionResult OnPostEliminarParte(int clienteId, string nombreEmpresa)
        {
            // Encontrar el cliente correspondiente en la lista
            var cliente = ClientesData.ClientesList.FirstOrDefault(c => c.Id == clienteId);

            if (cliente == null)
            {
                return NotFound();
            }

            // Encontrar y eliminar la parte correspondiente del cliente
            var parteEliminar = cliente.Partes.FirstOrDefault(p => p.Empresa == nombreEmpresa);
            if (parteEliminar != null)
            {
                cliente.Partes.Remove(parteEliminar);
            }

            return RedirectToPage("./Detalles", new { id = clienteId });
        }
    }
}