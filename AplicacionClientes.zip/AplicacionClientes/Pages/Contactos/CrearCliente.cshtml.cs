using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PantallaClientes.Models;
using System.Text.RegularExpressions;

namespace PantallaClientes.Pages.Contactos
{
    public class CrearClienteModel : PageModel
    {
        [BindProperty]
        public Cliente NuevoCliente { get; set; }

        public IActionResult OnGet()
        {
            return Page();
        }

        public IActionResult OnPost()
        {
            // Verifica si el ID es negativo
            if (NuevoCliente.Id < 0)
            {
                ViewData["ErrorMessage"] = "El ID no puede ser negativo.";
                return Page();
            }

            // Verifica si ya existe un producto con el mismo ID
            if (ClientesData.ClientesList.Any(c => c.Id == NuevoCliente.Id))
            {
                ViewData["ErrorMessage"] = "Ya existe un producto con este ID.";
                return Page();
            }

            // Valida el n�mero de tel�fono
            if (!EsNumeroTelefonoValido(NuevoCliente.Numero))
            {
                ViewData["ErrorMessage"] = "El n�mero de tel�fono no es v�lido.\nTiene que contener 9 d�gitos.";
                return Page();
            }

            // Valida el correo electr�nico
            if (!EsCorreoValido(NuevoCliente.Email))
            {
                ViewData["ErrorMessage"] = "El correo electr�nico no es v�lido.";
                return Page();
            }

            // Agrega el nuevo cliente a la lista en memoria
            ClientesData.ClientesList.Add(NuevoCliente);

            // Obt�n el t�rmino de b�squeda actual
            string searchString = Request.Query["searchString"];

            // Redirecciona a la p�gina de Clientes con el t�rmino de b�squeda
            return RedirectToPage("./Clientes", new { searchString });
        }

        private bool EsNumeroTelefonoValido(string numeroTelefono)
        {
            // L�gica de validaci�n del n�mero de tel�fono (m�ximo 9 caracteres y todos tienen que ser d�gitos)
            return !string.IsNullOrEmpty(numeroTelefono) && numeroTelefono.Length == 9 && numeroTelefono.All(char.IsDigit);
        }

        private bool EsCorreoValido(string correo)
        {
            // Si el correo est� vac�o o es igual a "No disponible", es v�lido
            if (string.IsNullOrWhiteSpace(correo) || correo.Trim().Equals("no disponible", StringComparison.OrdinalIgnoreCase))
                return true;

            // Expresi�n regular para validar el correo electr�nico
            string emailRegexPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(correo, emailRegexPattern);
        }

    }
}