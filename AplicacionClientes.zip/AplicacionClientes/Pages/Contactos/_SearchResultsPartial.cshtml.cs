using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AplicacionClientes.Pages.Contactos
{
    public class _SearchResultsPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
