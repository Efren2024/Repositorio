using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PantallaClientes.Models;

namespace PantallaClientes.Pages.Contactos
{
    public class DetalleParteModel : PageModel
    {
        [BindProperty]
        public Parte Parte { get; set; }

        [BindProperty(SupportsGet = true)]
        public int ClienteId { get; set; }

        private int _parteIdCounter = 1;

        public IActionResult OnGet(int parteId)
        {
            var cliente = ClientesData.ClientesList.Find(c => c.Partes.Exists(p => p.Id == parteId));
            if (cliente != null)
            {
                Parte = cliente.Partes.Find(p => p.Id == parteId);
            }
            else
            {
                return RedirectToPage("./Detalles", new { id = ClienteId });
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            if (Parte == null)
            {
                return NotFound();
            }

            var cliente = ClientesData.ClientesList.Find(c => c.Id == ClienteId);
            if (cliente != null)
            {
                // Si la parte ya existe en la lista de partes del cliente, actual�zala
                var existingParte = cliente.Partes.Find(p => p.Id == Parte.Id);
                if (existingParte != null)
                {
                    existingParte.Descripcion = Parte.Descripcion;
                    existingParte.FirmaElectronica = Parte.FirmaElectronica;

                    // Verifica si se ha cargado una nueva imagen
                    if (Request.Form.Files.Count > 0)
                    {
                        var file = Request.Form.Files[0];
                        if (file != null && file.Length > 0)
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                file.CopyTo(memoryStream);
                                existingParte.Foto = memoryStream.ToArray(); // Guarda la imagen en el modelo de parte
                            }
                        }
                    }

                    return RedirectToPage("./Detalles", new { id = ClienteId });
                }
                else
                {
                    // Si la parte no existe, es una nueva parte, asigna un nuevo ID �nico
                    Parte.Id = _parteIdCounter++; // Aseg�rate de tener un mecanismo para generar IDs �nicos, puedes usar una variable de contador como en tu c�digo original

                    // Verifica si se ha cargado una nueva imagen
                    if (Request.Form.Files.Count > 0)
                    {
                        var file = Request.Form.Files[0];
                        if (file != null && file.Length > 0)
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                file.CopyTo(memoryStream);
                                Parte.Foto = memoryStream.ToArray(); // Guarda la imagen en el modelo de parte
                            }
                        }
                    }

                    return RedirectToPage("./Detalles", new { id = ClienteId });
                }
            }

            // Si no se encuentra el cliente, redirige a alguna p�gina en caso de error
            return RedirectToPage("./Index");
        }
    }
}